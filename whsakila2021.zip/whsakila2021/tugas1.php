<?php include "database.php" ?>

<!DOCTYPE html>
<html>

<head>


  <!-- App favicon -->

  <!-- Highchart -->
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/data.js"></script>
  <script src="https://code.highcharts.com/modules/drilldown.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
  <script src="https://code.highcharts.com/modules/accessibility.js"></script>

  <!-- App css -->
  <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/style.css" rel="stylesheet" type="text/css" />

  <script src="assets/js/modernizr.min.js"></script>

</head>


<body>

  <!-- Begin page -->
  <div id="wrapper">

    <!-- Top Bar Start -->
    <div class="topbar">



      <!-- ============================================================== -->
      <!-- Start right Content here -->
      <!-- ============================================================== -->
      <div class="content-page">
        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="content-page">

          <!-- Start content -->
          <div class="content">
            <div class="container-fluid">

              <div class="row">
                <div class="col-12">
                  <div class="page-title-box">
                    <!-- <h4 class="page-title float-left">Example Pak Irwan</h4> -->

                    <div class="clearfix"></div>
                  </div>
                </div>
              </div>
              <!-- end row -->
              <div class="row">
                <div class="col-12">
                  <div class="card-box">
                    <div class="m-t-30" id="container"></div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                  <div class="card-box" style="height: 500px;">
                    <br>
                    <iframe name="mondrian" src="http://localhost:8080/mondrian/index.html" style="height:80%; width:100%; border:none; align-content:center"> </iframe>
                  </div>
                </div>
              </div>

            </div> <!-- container -->

          </div> <!-- content -->

          <script type="text/javascript">
            // Create the chart
            Highcharts.chart('container', {
              chart: {
                type: 'pie'
              },
              title: {
                text: 'Persentase Nilai Penjualan (WH Sakila) - Semua Kategori'
              },
              subtitle: {
                text: 'Klik di potongan kue untuk melihat detil nilai penjualan kategori berdasarkan bulan'
              },

              accessibility: {
                announceNewData: {
                  enabled: true
                },
                point: {
                  valueSuffix: '%'
                }
              },

              plotOptions: {
                series: {
                  dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.y:.1f}%'
                  }
                }
              },

              tooltip: {
                headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total</br>'
              },

              series: [{
                name: "Pendapatan By Kategori",
                colorByPoint: true,
                data: <?php
                      //TEKNIK GA JELAS

                      $datanya = $json_all_kat;
                      $data1 = str_replace('["', '{"', $datanya);
                      $data2 = str_replace('"]', '"}', $data1);
                      $data3 = str_replace('[[', '[', $data2);
                      $data4 = str_replace(']]', ']', $data3);
                      $data5 = str_replace(':', '" : "', $data4);
                      $data6 = str_replace('"name"', 'name', $data5);
                      $data7 = str_replace('"drilldown"', 'drilldown', $data6);
                      $data8 = str_replace('"y"', 'y', $data7);
                      $data9 = str_replace('",', ',', $data8);
                      $data10 = str_replace(',y', '",y', $data9);
                      $data11 = str_replace(',y : "', ',y : ', $data10);
                      echo $data11;
                      ?>

              }],
              drilldown: {
                series: [

                  <?php
                  //TEKNIK CLEAN
                  echo $string_data;

                  ?>



                ]
              }
            });
          </script>

          <footer class="footer text-right">
            <!-- <?= date('Y') ?> | &copy; TIM APES -->
          </footer>

        </div>


        <!-- ============================================================== -->
        <!-- End Right content here -->
        <!-- ============================================================== -->


      </div>
      <!-- END wrapper -->



      <!-- jQuery  -->
      <script src="assets/js/jquery.min.js"></script>
      <script src="assets/js/popper.min.js"></script><!-- Popper for Bootstrap -->
      <script src="assets/js/bootstrap.min.js"></script>
      <script src="assets/js/metisMenu.min.js"></script>
      <script src="assets/js/waves.js"></script>
      <script src="assets/js/jquery.slimscroll.js"></script>

      <!-- App js -->
      <script src="assets/js/jquery.core.js"></script>
      <script src="assets/js/jquery.app.js"></script>

</body>

</html>